# Pwn 01

Reverse the string to retrieve the flag.
