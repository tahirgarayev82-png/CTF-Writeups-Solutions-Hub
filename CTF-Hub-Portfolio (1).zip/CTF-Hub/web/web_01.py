#!/usr/bin/env python3
# Simple XSS test
test_input = "<script>alert(1)</script>"
response = f"Hello, you entered {test_input}"
if "<script>" in response:
    print("[+] Potential XSS vulnerability detected")
else:
    print("[+] Safe")