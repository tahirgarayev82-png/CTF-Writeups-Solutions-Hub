#!/usr/bin/env python3
import os, json
categories = ['reverse','crypto','web','pwn']
report = []
for cat in categories:
    path = os.path.join(os.getcwd(), cat)
    if os.path.exists(path):
        for f in os.listdir(path):
            if f.endswith('.py'):
                report.append({'category': cat, 'file': f, 'solved': True})
with open('report.json','w') as jf:
    json.dump(report,jf, indent=2)
print("[+] Report generated: report.json")