#!/usr/bin/env python3
# ROT13 decoding
flag_enc = "Guvf_Vf_Gur_Flag"
flag_dec = flag_enc.translate(str.maketrans(
    "ABCDEFGHIJKLMabcdefghijklmNOPQRSTUVWXYZnopqrstuvwxyz",
    "NOPQRSTUVWXYZnopqrstuvwxyzABCDEFGHIJKLMabcdefghijklm"))
print(f"[+] Decoded flag: {flag_dec}")