#!/usr/bin/env python3
# Reverse a string challenge
encoded_flag = "tamrof_detneserper"
decoded_flag = encoded_flag[::-1]
print(f"[+] Flag: {decoded_flag}")