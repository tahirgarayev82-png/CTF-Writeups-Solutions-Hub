#!/usr/bin/env python3
import base64
encoded_flag = "U1FMX1Rlc3RfRmxhZ19Vbml0"
decoded_flag = base64.b64decode(encoded_flag).decode('utf-8')
print(f"[+] Flag found: {decoded_flag}")