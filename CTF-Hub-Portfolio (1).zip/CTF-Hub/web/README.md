# Web 01

Simple XSS test on GET parameter.
